# tiled-vtkjs

Adaptive level of detail for large 3D datasets in
[vtk.js](https://kitware.github.io/vtk-js/).

**Status: early development.** APIs are provisional and will change without
notice.

## What it is

A standalone LOD runtime for large point clouds and supported explicit or implicit
3D Tiles 1.1 trees in vtk.js scenes. A shared scene coordinator governs frame time, memory,
submission work, interaction, and cross-member quality while each format owns
its traversal and renderer adapter. Only content relevant to the current camera
is fetched, decoded, and submitted. Decoded CPU payloads, renderer/GPU
residency, and active draw are separate lifecycle states.

Previously published as `pointcloud-lod`; this repository uses the `tiled-vtkjs`
identity and format-specific entry points.

## Install

```bash
npm install tiled-vtkjs
```

### Modules and renderer requirements

This is one package with three internal modules. `core` owns neutral scene
contracts, coordination, quality, memory, submission scheduling and geometry.
`points` owns point traversal, progressive prefixes, picking and PCT1/COPC.
`tiles3d` owns replacement traversal, subtree/content queues and glTF decoding.
Each format keeps its own VTK adapter and workers. Core imports neither format
nor vtk.js. Points and tiles3d depend on core and never import each other.

| Import                                     | Public API                                                                                                     |
| ------------------------------------------ | -------------------------------------------------------------------------------------------------------------- |
| `tiled-vtkjs` or `tiled-vtkjs/core`        | Geometry/camera contracts, member registry/coordinator, quality governor, memory pool and submission scheduler |
| `tiled-vtkjs/points`                       | Point sources, controller, progressive ordering and picking contracts                                          |
| `tiled-vtkjs/points/vtk`                   | Point member and renderer adapter                                                                              |
| `tiled-vtkjs/points/copc-worker`           | COPC module-worker endpoint                                                                                    |
| `tiled-vtkjs/tiles3d`                      | Supported tileset profile/configuration, decoder pool/types and coordinate helpers                             |
| `tiled-vtkjs/tiles3d/vtk`                  | Tiles member, mesh and shared Gaussian adapters                                                                |
| `tiled-vtkjs/tiles3d/gaussian-sort-worker` | Executable Gaussian module sort worker artifact                                                                |
| `tiled-vtkjs/tiles3d/decode-worker`        | Executable classic decoder worker artifact                                                                     |
| `tiled-vtkjs/tiles3d/codecs/*`             | Draco and Basis JavaScript/WASM assets                                                                         |

These subpaths isolate browser bundles. A core bundle has no format, codec or
VTK imports; each format's neutral entry excludes VTK and the other format.
Installation still includes both formats' dependencies. This initial layout
uses one version and release unit, rather than three independently published
packages. Examples, fixtures and replay tooling stay in the repository; the
published package excludes executable tooling and examples. The checked source
contract fixture remains included for consumer validation.

The VTK entries require `vtkPointSpriteMapper`, `vtkPointGaussianMapper` and compressed-texture support
from [the fork](https://github.com/PaulHax/vtk-js) at the exact revision in
[`vtkjs-fork.env`](./vtkjs-fork.env). Build it and make its ESM package and native
declarations available as `@kitware/vtk.js` in the consuming project:

```bash
source ./vtkjs-fork.env
# In a separate checkout of VTKJS_FORK_REPO at VTKJS_FORK_COMMIT:
npm ci && npm run build:esm
# In the consumer:
mkdir -p node_modules/@kitware
ln -s /absolute/path/to/vtk-js/dist/esm node_modules/@kitware/vtk.js
```

No npm vtk.js range is declared: registry releases cannot satisfy this fork
contract. Neutral entry points need no VTK runtime or declarations. Adapter
consumers use the fork's actual types, including its point mapper and texture
extensions.

For a source checkout, install tooling with `npm ci --ignore-scripts` followed
by `npm rebuild` to run dependency install scripts. Link the built pinned VTK
package as above, then run `npm run prepare`. Declaration
emission uses its native types, so a Git install without that setup is not a
supported shortcut.

The old combined `/vtk`, `/copc-worker` and `/tiles3d-decode-worker` exports are
removed. Point symbols formerly at the package root now come from `/points`;
mesh configuration and decoder symbols now come from `/tiles3d`. See
[the module and worker contracts](./docs/modules.md) for migration and service
ownership.

## Usage

```js
import "@kitware/vtk.js/Rendering/Profiles/Geometry";
import { createCopcTileSource, createLodController } from "tiled-vtkjs/points";
import { createRendererAdapter } from "tiled-vtkjs/points/vtk";

// A coalescing render request the host owns (must not render synchronously
// more than once per event-loop turn).
let frameQueued = false;
const scheduleRender = () => {
  if (frameQueued) return;
  frameQueued = true;
  requestAnimationFrame(() => {
    frameQueued = false;
    renderWindow.render();
  });
};

// 1. A tile source. COPC reads a static .copc.laz over HTTP Range requests,
//    so any static file host works with no tile server:
const source = await createCopcTileSource({
  source: "https://host/cloud.copc.laz",
});

// 2. A renderer adapter turns tile batches into vtk.js actors in your renderer.
const adapter = createRendererAdapter({ renderer, scheduleRender });

// 3. The controller decides which octree nodes are resident for the camera
//    and streams batches to the adapter.
const controller = createLodController({
  source,
  onTiles: (batch) => adapter.applyBatch(batch),
  onDrawPlan: (plan) => adapter.applyDrawPlan(plan),
  onPointDiameterCssPx: (diameter) => adapter.setPointDiameterCssPx(diameter),
  presentation: { mode: "auto", userScale: 1 },
  scheduleRender,
});

// Feed the controller a plain camera description on every camera change. The
// projection mode is explicit; an orthographic view carries `parallelScale`
// (the world-space half-height of the viewport) instead of `fovY`:
controller.setCamera({
  projection: "perspective",
  viewProj,
  position,
  fovY,
  viewportWidthCssPx,
  viewportHeightCssPx,
});
adapter.setDevicePixelRatio(window.devicePixelRatio);

// Tear down when done. Both are idempotent, and BOTH are required: the
// controller's teardown hands its tiles back as removals, which the adapter
// answers by pooling those actors for reuse, so disposing only the controller
// leaves GPU resources alive with nothing left to reclaim them.
controller.dispose();
adapter.dispose();
source.dispose?.();
```

For servers that reproject or transform points per tile, use
`createHttpTileSource({ endpoint, metadata })` instead of the COPC source; it
speaks a compact binary tile protocol (`PCT1`).

Every PCT1 tile is reordered client-side into progressive prefix order, into
freshly allocated position and color buffers, so a host that wraps
`createHttpTileSource` in a worker of its own can transfer both.

In an interactive browser, put the COPC source behind one module worker. The
worker owns its laz-perf instance, accepts concurrent range reads, and transfers
decoded position/color buffers back without copying. For example, make the
worker entry:

```js
// copc.worker.js
import { serveCopcTileSourceWorker } from "tiled-vtkjs/points/copc-worker";

serveCopcTileSourceWorker();
```

Then create the source from the main thread (serve `laz-perf.wasm` at the URL
you provide):

```js
import { createCopcWorkerTileSource } from "tiled-vtkjs/points";

const source = await createCopcWorkerTileSource({
  source: "https://host/cloud.copc.laz", // Blob/File also works
  createWorker: () =>
    new Worker(new URL("./copc.worker.js", import.meta.url), {
      type: "module",
    }),
  lazPerfWasmUrl: new URL("./laz-perf.wasm", document.baseURI).href,
});
```

The source calls `createWorker` once per worker and owns every worker it
makes; call `source.dispose()` after disposing its controller. The first worker
reads the hierarchy, and every worker decodes tiles, since decoding is what
bounds how fast a COPC view fills in. `workers` sets how many there are; it
defaults to one fewer than the logical cores, from one to three. If the first
worker fails the source fails; a decoder that fails is dropped, and the tiles it
held fail and are retried on the workers left. Cancellation still settles only
when a worker's physical read or decode ends, so controller concurrency remains
bounded.

### Application flows and primary controls

There are two loops in a typical integration:

- the required camera → selection → streaming → render loop;
- an optional frame-time loop that automatically changes the point budget.

Point presentation is a separate choice: it can follow the streamed density
automatically or stay at a fixed size.

#### Camera, selection, streaming, and render

```text
camera or budget changes
  → select a parent-closed set of visible octree nodes
  → update Auto point diameter for the selected terminal density
  → fetch missing hierarchy pages and tile payloads
  → make each decoded tile resident
  → recompute the ready terminal coverage frontier
  → submit one batched renderer delta
  → paint one coalesced frame
```

`setCamera()` is the normal entry point. It should receive the actual camera
used for rendering, including the CSS viewport height. The first change
selects immediately; repeated changes are rate-limited by `selectionDelayMs`
and the last one still gets a trailing selection. Camera values are copied,
so hosts may update and reuse their position arrays and view-projection matrices.

Selection is parent-closed: a child adds points without replacing its parent.
While a selected child is still loading, missing from the hierarchy, or
excluded by the point budget, the closest ready ancestor continues to cover
that region. At a same-level point-budget boundary, an already selected node
keeps an eight-CSS-pixel-equivalent centre-cone advantage. This hysteresis
prevents nearly tied tiles from trading places under tiny camera changes while
allowing culling,
refinement-cutoff transitions, and materially better candidates to take effect.
Candidates are visited breadth-first and in concentric 3D cones around the
camera's centre ray, with projected detail breaking ties. When the next
candidate does not fit, that pass stops adding optional detail instead of
spending the remainder on either a cheaper horizon tile or a deeper foreground
child. The next budget increase therefore extends the current band before
descending another level.

The **ready terminal coverage frontier** is the set of ready nodes currently
responsible for the ends of those visible branches. Some may be fine children
while another is still a coarse parent, so its statistics describe exactly
what is on screen while payloads stream.

Auto presentation follows the corresponding **selected** terminal density. It
projects each selected terminal's world-space point spacing into CSS pixels and
uses the largest spacing as the common point diameter, after applying the
configured bounds and `userScale`. Hierarchy- and budget-blocked branches retain
their closest sampled parent. Tile readiness does not change the diameter: the
selection adopts its completed density once, then newly decoded tiles add
detail without shrinking every point already on screen.

Tile arrivals and diameter changes can both request a render. `scheduleRender`
must therefore coalesce requests, normally with `requestAnimationFrame`, and
must not paint synchronously from either callback. That lets a newly resident
tile, the frontier-derived diameter, and the renderer batch land before the
same frame.

#### View-quality flow: adaptive or fixed

With a `ViewGovernor`, the host closes a frame-time feedback loop:

```text
paint frame
  → recordTransientFrame({ hostFrameMs, vtkFrameMs })
  → recordCapacitySample(clean asynchronous GPU result)
  → governor adjusts one normalized view-quality fraction
  → the next prepareFrame demand-caps and water-fills it across members
  → each point member maps its allocation to selection + draw density
  → moving changes thin existing VBO prefixes; settled changes may reselect
  → needsFrame() says whether another measurement is useful
```

The governor is optional. It controls a format-neutral fraction in `[0.05, 1]`
and never reads the renderer or schedules a frame on its own. The streamed
scene coordinator reports completed frames, camera motion, and aggregate work,
then water-fills quality by projected importance and member demand. Memory is
a separate byte allocation from the page-wide pool. See
[Adaptive quality](#adaptive-quality) for the complete wiring.

For one cloud, a fixed budget can still be set directly:

```js
controller.setPointBudget(1_500_000);
```

The effective budget is still capped by the controller's memory-derived point
ceiling. Selection also reserves each tile's logical payload bytes, including
per-tile overhead. Before decoding it assumes position and RGB arrays; afterward
it uses the decoded array sizes. Learned costs survive CPU-cache eviction, so
an oversized payload is not repeatedly fetched under the same byte budget.
A higher budget permits more selected detail; it does not require that every
dataset contain that many useful visible points.

#### Point-presentation flow: Auto or Fixed

Auto presentation follows the density of the selected coverage:

```js
controller.setPresentation({
  mode: "auto",
  userScale: 1,
  minDiameterCssPx: 1.25,
  maxDiameterCssPx: 4,
});
```

- `userScale` changes overlap without changing selection: 1 matches the full
  estimated point spacing, above 1 overlaps footprints, and below 1 leaves
  separation between them.
- `minDiameterCssPx` prevents very dense detail from becoming sub-pixel.
- `maxDiameterCssPx` limits how large coarse points may become.

For a constant point footprint, use Fixed presentation. No frontier
measurement changes it:

```js
controller.setPresentation({ mode: "fixed", diameterCssPx: 2 });
```

Keep CSS size separate from framebuffer density. Report display-density
changes through `adapter.setDevicePixelRatio(window.devicePixelRatio)`.

#### Direct controls and lifecycle

These methods are useful when application policy lives outside the library:

| Control                                               | Effect                                                                                                                                                                     |
| ----------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `controller.setPointBudget(points)`                   | Set the visible-point target directly. Use this instead of a governor for a fixed or externally managed budget.                                                            |
| `controller.setDensityFraction(fraction)`             | Redistribute that fraction of selected points into parent-closed, importance-ranked tile prefixes without changing selection, I/O, actors, or VBO contents.                |
| `controller.setPresentation(...)`                     | Switch live between Auto and Fixed point presentation.                                                                                                                     |
| `controller.setRefinementCutoffPx(pixels)`            | Stop descending when a node's projected spacing is below this threshold. Lower values allow finer traversal; the point and memory budgets still apply.                     |
| `controller.refresh()`                                | Force immediate reselection against the current camera, useful after external state changes that do not produce a new camera value.                                        |
| `controller.beginInteraction()` / `endInteraction()`  | Mark explicit camera interaction for controller diagnostics and immediate selection. Calls may be nested.                                                                  |
| `governor.beginMotion(kind)`                          | Hold the adaptive budget in its moving-camera regime. Use `"explicit"` for announced gestures and `"inferred"` for playback or programmatic motion detected by the host.   |
| `governor.recordCameraChange()`                       | Report a rendered-camera change directly. The governor owns the trailing camera-stability timer. Prefer `noteRenderedCameras()`, which infers this.                        |
| `governor.noteRenderedCameras(views, scheduleRender)` | Hand the governor the camera each view actually rendered, keyed by anything stable, and let it classify the motion. Covers playback, scrubbing and programmatic motion.    |
| `governor.resetMotionBaselines()`                     | Forget those baselines when a view stops feeding cameras, so its next one is a baseline again rather than every metre travelled since.                                     |
| `governor.setOptions(options)`                        | Re-target a running governor. Memberships, motion references and camera stability survive; only the adaptive tracks restart. An unusable value throws and changes nothing. |
| `adapter.setPointDiameterCssPx(pixels)`               | Set point size outside the controller. Omit `onPointDiameterCssPx` when the application owns this value so two policies do not compete.                                    |
| `adapter.setDevicePixelRatio(ratio)`                  | Update CSS-to-framebuffer scaling without changing selection or the CSS point diameter.                                                                                    |
| `adapter.applyDrawPlan(plan)`                         | Apply per-tile prefix counts when draw policy lives outside the controller. Use `controller.setDensityFraction()` when the controller owns draw policy.                    |
| `adapter.setResourceCeilingBytes(bytes)`              | Bound GPU resources retained in the adapter's actor-reuse pool. A host can feed it the controller's current `memoryBudgetBytes`.                                           |
| `adapter.setVisible(false)`                           | Hide drawing only. Actors, GPU resources, selection, and streaming remain live for an immediate show.                                                                      |
| `controller.setActive(false)`                         | Stop selection and tile fetches, emit removals that move actors into the bounded adapter pool, and retain decoded payloads in the bounded CPU cache.                       |
| `controller.setSource(source)`                        | Replace the dataset or revision, dropping old hierarchy, residency, cache, and pending results before bootstrapping the new source.                                        |
| `controller.governorInputs()`                         | Point-specific demand, importance, memory ceiling, and physical-operation inputs used by the point member. Prefer it to `stats()` on a per-frame path.                     |
| `controller.setModelMatrix(matrix)`                   | The transform the tiles draw under, so cameras and picks are given in world coordinates. Must be a similarity; an unchanged matrix is a no-op, so forward it every pass.   |
| `adapter.setBaseMatrix(matrix)`                       | Apply or update the registration transform without rebuilding tile payloads. Pair it with `controller.setModelMatrix()` so selection and drawing agree.                    |

The main dials and their tradeoffs are:

| Dial                              | Primary effect                                             | Tune when                                                      |
| --------------------------------- | ---------------------------------------------------------- | -------------------------------------------------------------- |
| `pointBudget` or governor targets | Visible detail and render cost                             | First performance/quality control                              |
| `presentation`                    | Point coverage and apparent density, not selected detail   | Points look porous or overly solid                             |
| `refinementCutoffPx`              | How far hierarchy traversal is allowed to descend          | Storage has detail finer than the view needs                   |
| `memory`                          | Logical resident payload ceiling, checked during selection | Multiple clouds compete for GPU memory                         |
| `cacheBytes`                      | Decoded CPU payloads retained for fast reselection         | Revisiting views causes too much decoding or uses too much RAM |
| `fetchConcurrency`                | Parallel tile fetch/decode work                            | The source is under-filled or decoding saturates the client    |
| `hierarchyConcurrency`            | Parallel hierarchy-page work                               | Deep traversal stalls waiting for hierarchy                    |
| `selectionDelayMs`                | Reselection rate and recent-read cancellation grace        | Camera motion causes selection or cancel/refetch churn         |
| `interactionSettleMs`             | Governor delay for declaring the rendered camera stable    | Quality rises too early or too late after motion               |

Visibility, activity, and disposal answer different questions:

```text
setVisible(false)  → draw nothing; keep actors and streaming
setActive(false)   → stop tile fetches; pool submitted actors and cache payloads
dispose both       → release controller state and every adapter-owned actor
```

Always dispose both the controller and adapter when the cloud is permanently
removed.

### vtk.js examples

The runnable app in [`examples/vtk`](./examples/vtk/) contains five examples.
Two use `createLodController` directly, which is all a single point cloud
needs:

- **Simple** (`/simple/`) is the integration starting point: one worker-backed
  COPC source, one fixed-budget controller, one renderer adapter, and the
  default vtk.js camera interaction. It intentionally has no governor,
  performance chart, telemetry recorder, diagnostic table, or browser-test
  API.
- **Instrumented** (`/instrumented/`) demonstrates adaptive quality,
  fixed/adaptive presentation, custom point-cloud camera interaction, local
  telemetry, and the diagnostic hooks exercised by the browser suite.

Three more use the member API; `createStreamedSceneCoordinator` with
`createTiles3dMember` and `createPointCloudMember`; which is what a scene of
more than one streamed dataset needs, and are the reference for it:

- **Explorer** (`/`) is the page a visitor lands on: add any number of point
  clouds and 3D Tiles datasets to one scene, each with its own controls, over
  one shared view governor. It is also the page the recorded-gesture benchmark
  drives; `?record=1` adds the capture panel and nothing else loads it.
  The 3D Tiles presets include Jastrzębia Góra, a geolocated Gaussian
  reconstruction with 103.5 million retained splats, 8,784 tiles and 13 hierarchy
  levels. Gaussian tiles share the same dataset controls, coordinator and
  diagnostics as meshes and point clouds. [Data attribution and hosting](./examples/vtk/scene/GAUSSIAN_DATA.md)
  describe the source license and local proxy. [Gaussian integration](./docs/gaussian-splats.md)
  describes the supported content profile and resource accounting.
- **Mesh** (`/mesh/`) streams 3D Tiles: every building in the Netherlands at
  LoD2.2, live from [3DBAG](https://docs.3dbag.nl/) with no key.
- **Combined** (`/combined/`) puts AHN4 lidar and 3DBAG buildings in one scene
  sharing one memory pool, one submission scheduler and one view governor. Its
  panel shows each member's claimed share of the view beside the quality the
  governor gave it back, which is the only place that negotiation is visible.

Both meet in a local ENU frame whose Z is NAP: the mesh arrives in ECEF and is
placed by `tilesetToScene`, the lidar arrives in RD New (EPSG:28992) and is placed
by a model matrix, and `examples/vtk/scene/places.ts` derives both from one
origin. Public data is rarely shaped the way a strict reader wants, and
`examples/vtk/scene/` carries what that costs at the host boundary: resolving
3DBAG's external tilesets on the `fetchTileset` seam, rotating bounding volumes
into the frame its Y-up glTF content uses, and repairing colliding meshopt
fallback-buffer offsets on the way past `fetchContent`. Each is commented where
it lives.

The dataset dropdown also offers **Freeman Alley · textured mesh (NYT)**,
streamed on demand from the [New York Times tileset](https://int.nyt.com/data/3dscenes/ONA360/TILESET/0731_FREEMAN_ALLEY_10M_A_36x8K__10K-PN_50P_DB/tileset_tileset.json).

### Supported 3D Tiles profile

The mesh member deliberately accepts a narrow, typed 3D Tiles 1.1 profile:

- `REPLACE` refinement, affine transforms, oriented `box` bounding volumes,
  and one glTF/GLB content per tile;
- explicit trees, including contentless structural ancestors;
- implicit `QUADTREE` roots with four subtree levels, 1 to 31 available levels, relative same-root URI
  templates containing exactly one `{level}`, `{x}`, and `{y}` placeholder;
- binary subtree version 1 with inline availability bitstreams and one
  tileset-schema property table supplying a required 12-component
  `TILE_BOUNDING_BOX` for every available tile. Metadata bounds override
  subdivision-derived bounds; missing or malformed bounds are errors;
- glTF required extensions `KHR_draco_mesh_compression`, `KHR_texture_basisu`,
  `KHR_materials_unlit`, `KHR_mesh_quantization`, and `EXT_meshopt_compression`. Other required extensions
  fail as `TileUnsupportedExtensionError` with tile URI and decode stage.
- glTF `TRIANGLES` and `TRIANGLE_STRIP` primitive modes; other primitive modes fail explicitly.

Retired mesh resources stay attached but invisible while pooled, preserving vtk
render nodes and GPU buffers/textures across reuse. They are excluded from draws
and picks. Eviction under the residency ceiling removes and deletes them.

Implicit subtrees have a bounded revision-scoped cache independent of decoded
mesh residency. Unknown visible boundaries request their subtree and hold the
nearest submitted `REPLACE` ancestor; an unknown subtree is never interpreted
as empty availability. Camera changes cancel fetches for culled boundaries,
and configuration generations retire old hierarchy and content work together.

Unsupported `OCTREE`, ADD refinement, regions/spheres, multiple contents,
external subtree buffers or schemas, unsafe/absolute template paths, legacy
content containers, and malformed metadata produce named
`TilesetUnsupportedError` or `TilesetValidationError` values rather than a
partially interpreted scene.

### Streamed-scene coordinate semantics

`ScenePoint` is a branded tuple in canonical, unexaggerated scene coordinates;
plain numeric tuples do not satisfy it. Mesh vertices are decoded and cached in
that canonical frame. Registration placement and display-only vertical
exaggeration are renderer matrices, so changing exaggeration does not invalidate
decoded content or move data that the host has stored.

Picking tests only the member's exact drawn tile set. The ray and returned
`rayDepth` use the displayed frame, including exaggeration, while the returned
`scenePoint` is reconstructed in the canonical unexaggerated frame. Occlusion
uses that same displayed-frame depth and exact draw set, so hidden, culled, or
submitted-but-not-drawn geometry cannot pick or occlude.

Both load either a local `.copc.laz` file (read through `Blob.slice()` in a
source worker) or a COPC URL (HTTP Range from that worker), frame it
automatically, and stream it through a controller and renderer adapter. The
instrumented example also wires one view governor for the view.

The instrumented example defaults to Auto presentation at `0.5×`, using half the
estimated point spacing as its diameter. Its sidebar can switch to a constant
Fixed CSS-pixel diameter when comparing presentation policies.

Its controls are all runtime, so one build loads any dataset:

- **Point budget**; `Adaptive` gives the number to a `ViewGovernor`; `Fixed`
  gives it straight to `setPointBudget`.
- **Point size**; `Fixed` directly controls the CSS-pixel diameter; `Auto`
  controls the density-derived diameter's scale and defaults to `0.5×`.
- **Moving / settled target**; the two regimes' frame-time targets. Changing
  either replaces the governor, since the library fixes its options at
  construction.
- **Maximum budget**; the optional configured maximum. Blank leaves the
  memory-derived ceiling as the only upper bound.
- **Projection**; perspective or orthographic, preserving the world height the
  viewport covers, so the only thing a toggle changes is the law selection
  refines by (an orthographic zoom moves `parallelScale`, not the eye).

The panel answers "why is it drawing N points" without reading internal state:
regime and what is holding it, explicit versus inferred motion, target frame
time, median interval and late-frame share, sample count, adaptive track budget, configured
maximum, memory ceiling, aggregate view budget, this cloud's share, the last
adjustment and its reason, the binding constraint, and the physical tile and
hierarchy work counts; next to the controller's selection, decoded-memory,
GPU-residency and frame-time statistics. The current moving, settling, or
settled status is the first row of that budget chain.

The page holds an explicit motion reference for the interactor's gestures and
reports rendered-camera changes to the governor, which owns the single trailing
stability timer. It uses displayed cadence for immediate pressure and
asynchronous WebGL timer queries for lasting capacity. Controller work and
renderer resource revisions reject frames crossed by streaming, decode, batch,
or first-upload work. Clean displayed cadence is the fallback when hardware GPU
timing is unavailable. The page repaints while `needsFrame()` is true.
`window.pointCloudExample` exposes `stats()`, `setProjection()`,
`setBudgetMode()` and `dispose()` for browser tests.

Install a vtk.js build containing `vtkPointGaussianMapper` as described in
[renderer requirements](#modules-and-renderer-requirements), then run:

```bash
npm run example
```

Vite serves the explorer at the printed root URL, and the others at
`/instrumented/`, `/simple/`, `/mesh/` and `/combined/`. The streamed-scene pages decode in a
classic worker built by `npm run build`, so build the package before serving
them.

If that vtk.js build is outside this package's `node_modules`, point the example
at its ESM package directory:

```bash
VTK_JS_DIR=/path/to/vtk-js/dist/esm npm run example
```

A `?place=` query parameter opens the mesh and combined examples on a named
place. A `?url=` query parameter loads a cloud on startup in either point-cloud
example. On the
instrumented example, add `&telemetry=1` to begin a local performance trace before
that source opens.

The **Local telemetry** controls record only in the current browser tab. Start,
stop, clear, and download produce a bounded JSON trace; nothing is uploaded.
The trace identifies the WebGL vendor and renderer (including an explicit
software-renderer flag), viewport and device-pixel ratio, camera and control
state, controller/adapter/governor statistics, rAF cadence, synchronous vtk
time, long tasks, source/hierarchy/tile work, and renderer-batch handoff.

Every source or renderer work transition increments a revision. A frame is
`clean` only when that revision stayed unchanged across the complete interval
since the previous presentation, no work remained pending, and the controller
reported no queued, physical, or undecoded selected-tile work. This preserves
the evidence needed to distinguish steady rendering capacity from a frame that
overlapped streaming. The same controls are scriptable through
`window.pointCloudExample.telemetry` (`start`, `stop`, `clear`, `environment`,
`summary`, `trace`, `download`, and `mark`).

Browser checks use SwiftShader by default and must not be treated as GPU
benchmarks. On a WSLg machine with GPU forwarding, run the telemetry check in a
headed hardware browser with:

```bash
TILED_VTKJS_BROWSER_GPU=1 npm run test:browser -- test/browser/telemetry.spec.ts
```

That mode asserts the reported renderer is not software, so a silent fallback
cannot pass as a hardware measurement.

To capture a repeatable initial load, picked ROI, rapid wheel zoom, long close
orbit sweep, near-horizontal local pan, and return to overview, supply a cloud URL
and optional artifact path:

```bash
TILED_VTKJS_TELEMETRY_URL='https://example.test/cloud.copc.laz' \
TILED_VTKJS_TELEMETRY_OUT='artifacts/telemetry/cloud.json' \
VTK_JS_DIR=/path/to/vtk-js/dist/esm \
npm run telemetry:capture
```

The capture starts before the source opens and adds phase markers to the JSON,
including the tight and restored broad views after each has settled.
By default, the first run caches the complete COPC under
`artifacts/telemetry/cache/`; later runs replay real range requests from that
local file with deterministic 40 ms request latency and an 80 Mbps per-request
transfer rate. This removes changing WAN conditions while preserving range
traffic, concurrency, cancellation, decoding, and rendering. Adjust the replay
with `TILED_VTKJS_TELEMETRY_LATENCY_MS` and
`TILED_VTKJS_TELEMETRY_MBPS`, force a new download with
`TILED_VTKJS_TELEMETRY_REFRESH=1`, or select the original remote behavior
with `TILED_VTKJS_TELEMETRY_NETWORK=live`.

The same scenario can compare the optional governor with the conventional
fixed-budget policy:

```bash
TILED_VTKJS_TELEMETRY_BUDGET_MODE=fixed \
TILED_VTKJS_TELEMETRY_POINT_BUDGET=5000000 \
TILED_VTKJS_TELEMETRY_INTERACTION_DENSITY=0.6 \
npm run telemetry:capture
```

The defaults are `adaptive`, 2,000,000 points, and full interaction density.
The point and interaction-density values affect only fixed mode.

It rejects software rendering and checks that the trace is structurally usable;
it deliberately does not turn machine-specific frame times into pass/fail
thresholds. If no output path is supplied, the timestamped trace is written
under `artifacts/telemetry/`. It is tagged `*.perf.spec.ts`, runs only through
the opt-in `test:perf`/`telemetry:capture` commands, and is excluded from normal
unit and browser test runs. If no URL is supplied, the capture skips.

Remote URLs must allow cross-origin `Range` requests. Raw LAS/LAZ is not
streamable by the COPC source; convert it with a proven native COPC writer
PDAL's `writers.copc` or `untwine`; which is also what server-side preparation
pipelines should run. No JavaScript/browser COPC writer is used or accepted
here, not even as a development dependency: the one evaluated preserved the
point count but silently rewrote RGB point format 7 as non-RGB format 6.

### Fixed quality

The controller is a complete fixed-budget viewer without a governor. Fixed
quality does not disable demand rendering, screen-space prioritization,
progressive point order, a worker-backed COPC source, decoded and GPU reuse,
memory ceilings, or per-tile draw plans; only frame-time learning is absent.

```js
controller.setPointBudget(5_000_000);
```

An application that wants a simple fixed interaction policy can lower only the
draw allowance while input is active. This keeps the fixed selection resident
and uses the same importance-ranked tile prefixes as adaptive mode:

```js
controller.beginInteraction();
controller.setDensityFraction(0.6);
// ...camera input...
controller.setDensityFraction(1);
controller.endInteraction();
```

This two-state policy is optional. A constant fixed budget is the smallest and
most predictable configuration.

### Adaptive quality

A controller on its own draws to whatever fixed point budget you set. Adaptive
views use one streamed-scene coordinator, which owns one normalized governor
and allocates its fraction across every format member in the view.

Two regimes, two targets. A moving camera is being steered, so it gets the
tighter **16 ms** target and trades drawn points for responsiveness; a settled
camera is being read, so it gets the looser **33 ms** target and spends the
extra frame time on detail. Both tracks start at quality **1** and never drop
below **0.05**.

Frame samples are presentation intervals, and those arrive in whole display
refreshes. Each track grants its target a whole number of refreshes (at 60 Hz,
one while moving and two at rest; at 120 Hz, two and four) and counts the frames
in its last 30 that missed them:

- More than a fifth late while moving, or more than half at rest, lowers
  quality: by 15%, or, when most frames are late, by what the median refresh
  count says the overload is. A still view tolerates more because a late frame
  there only delays refinement, while a step back is a visible change with
  nothing moving to hide it.
- A full window without a late frame probes one step up once the level has held
  for a while (1.5 s while moving, 0.4 s at rest). A probe that fails returns to
  the level it left, and later probes close half the distance to the level found
  too expensive for the next 15 s. With no such level remembered, probes step
  twice as far and come twice as soon.
- Anything between holds, so a steady view keeps its detail instead of searching.

At rest, frames that present in fewer refreshes than their budget show real
headroom, and a probe spends most of it in one step. A still view that fitted a
moving frame's budget seeds the next gesture at that level.

Pending streaming work withholds capacity samples, so an emergency path answers
those frames instead. It cuts only when most of the last five moving frames took
more than 3.5 times the budget (under about 17 fps at 60 Hz), takes back a cut
that left frames no faster and then holds off cutting for 5 s, and gives back a
cut that worked after a second of on-time frames. Frames within 500 ms of a
pause of a second or more feed no decision: a GPU leaving its idle clocks draws
them several times slower than the same scene a moment later.

The governor learns the refresh period from the shortest intervals it has
presented, never believing anything above 17 ms, so a page slower than its
display cannot mistake its own best frame for the floor.
`stats().configuredFrameTimeMs` keeps the number that was asked for beside
`targetFrameTimeMs`, the whole refreshes granted to it. Point
`minBudget`/`maxBudget` remain point-member clamps; they are not governor
options. The point member keeps the denser proven stationary selection while
moving and expresses the interaction allocation as parent-closed per-tile
prefixes.

```js
import { createMemoryPool, createStreamedSceneCoordinator } from "tiled-vtkjs";
import { createPointCloudMember } from "tiled-vtkjs/points/vtk";

const coordinator = createStreamedSceneCoordinator({
  scheduleRender,
  memory: pageMemoryPool ?? createMemoryPool(),
});
const cloud = createPointCloudMember(
  coordinator.context(renderer, dpr),
  config,
);
coordinator.register(cloud, {
  id: "cloud-1",
  qualityManaged: config.adaptive,
  qualityTargets: config.adaptive ? config.adaptiveOptions : undefined,
});

// Hold the moving regime while the camera moves. References compose across
// sources and the regime ends only when the last one is released, so an
// inferred playback motion overlapping a pointer gesture behaves correctly.
coordinator.beginInteraction();
// ...camera moves...
coordinator.endInteraction();

// Motion the host cannot announce; playback, scrubbing, programmatic
// animation; is classified by the governor. Hand it the camera each view
// actually rendered, once per rendered frame, keyed by anything stable:
coordinator.noteRenderedCameras(new Map([[renderer, view]]));
// It owns the jitter epsilon, ignores the clip-z row a host rewrites when
// tiles arrive, holds one inferred motion reference for the whole burst, and
// releases it after the debounce; asking for one frame back, because the
// settled regime cannot refine quality it never measures. A scene change with
// an unchanged camera is not motion.

// Immediately before each paint: member preparation, one bounded submission
// drain, and the frame's allocations.
coordinator.prepareFrame(frameSerial);

// When a view stops feeding cameras, drop its baseline. Otherwise the first
// camera after it returns is compared against one from before it left, and all
// the travel between reads as a gesture nobody made.
coordinator.recordHostFrame({ hostFrameMs, vtkFrameMs, gpuMs });
if (coordinator.needsFrame()) scheduleRender();
coordinator.dispose();
```

Members receive allocations only in `prepareFrame`, at most once per frame.
When a work report or a lifecycle change moves an allocation, the coordinator
asks for a frame, and `needsFrame()` stays true while any allocation, including
one a new governor fraction moved, waits for a frame to apply it.
`recordHostFrame` returns whether the frame was sampled, whether the sample may
train quality, and its regime, so a host never reads `stats()` per frame.

The point member reports retry-aware `workPending` through the coordinator
context's work callback. Fixed point members still register for byte and work
accounting but bypass normalized quality allocation.

`coordinator.stats()` reports the normalized view fraction, target-override
member, governor motion/samples, byte allocations, and each member's neutral
inputs. Point-specific diagnostics including configured point ceiling and
effective full point ceiling live on `PointCloudMember.stats()`.

## Picking

`controller.pickPoint(view, cursorXCssPx, cursorYCssPx)` resolves a cursor to
a point **on the cursor ray** at the support depth of the frontmost rendered
sample near the cursor; it never snaps to the vertex itself. The query runs
only over the tile set last submitted to the renderer (WYSIWYG: what is not
drawn cannot be picked), and answers

- `{ status: "hit", scenePoint, rayDepth, distancePx }` for a supported depth,
- `{ status: "miss" }` for a valid sweep that found no sample within any
  pick bucket, or
- `null` when the query is unavailable (inactive/disposed controller, invalid
  camera or viewport, singular view-projection, non-finite cursor); never to
  be conflated with a miss.

Candidates gather in escalating css-pixel buckets around the cursor; the
smallest non-empty bucket wins, then its minimum-depth point. The bucket radii
(`PICK_RADII_CSS_PX` = `DEFAULT_PICK_PIXEL_RADIUS` ×
`DEFAULT_PICK_PIXEL_RADIUS_MULTIPLIERS` = 10 × (1, 2, 10) css px) mirror
`DEFAULT_PICK_PIXEL_RADIUS` and `DEFAULT_PICK_PIXEL_RADIUS_MULTIPLIERS` in
telesculptor-web's `scene/ray_depth.py`; keep the two definitions in lockstep
so a pick one side accepts is never the other side's miss.

## Architecture

```
TileSource  ──▶  LOD controller  ──▶  renderer adapter
(hierarchy +     (frustum cull,       (vtkPolyData +
 tile payloads)   screen-space         vtkPointGaussianMapper
                  error, point         per tile)
                  budget, LRU)
```

- **TileSource**; abstract interface over an octree tile store: dataset
  metadata, hierarchy pages with conservative render-space bounds and effective
  spacing for every node, and per-node point payloads. Two
  implementations ship:
  - `createCopcTileSource` reads [COPC](https://copc.io/) files directly
    over HTTP Range requests (via the `copc` package), so any static file
    host works with no tile server at all;
  - `createCopcWorkerTileSource` exposes the same contract while a small
    pool of workers performs COPC I/O, LAZ decoding, and extraction; final
    typed arrays transfer to the controller without a copy;
  - `createHttpTileSource` speaks a small revision-scoped hierarchy/tile
    HTTP protocol with a compact binary tile format (`PCT1`: Float64 tile
    origin + tile-local Float32 positions + Uint8 RGB) for servers that
    reproject or transform points per tile.
- **LOD controller** (`createLodController`); decides which nodes are
  resident: frustum culling, 3D centre-ray cone priority with projected-detail
  tie-breaking, and a visible-point budget with a parent-closed selection
  invariant (COPC hierarchies are
  additive, so that invariant alone guarantees hole-free refinement),
  coarse-first fetching with bounded concurrency and cancellation,
  byte-budgeted LRU caching of deselected tiles, and batched delivery.
  Tiles and hierarchy pages get separate ceilings (`fetchConcurrency`,
  default 6, and `hierarchyConcurrency`, default 4) because a page unblocks
  selection for a whole subtree and must not queue behind tile fetches that
  cannot be chosen correctly until it lands. Both ceilings count _physical_
  operations: cancellation is advisory wherever the underlying reader takes
  no signal, so an abandoned read keeps its slot until its promise settles
  and a look-away/look-back storm cannot multiply real I/O.
  Fixed presentation keeps one CSS-pixel diameter; Auto presentation derives
  the diameter from the largest projected spacing on the selected terminal
  coverage frontier, clamped to the presentation's min/max and scaled by
  `userScale`. Progressive drawing reserves coarse parent coverage, then gives
  complete or partial nested prefixes to the highest projected-importance
  branches. Auto sizing follows each terminal's effective prefix density, and
  CPU picking examines the same per-tile plan the renderer draws. Two CSS
  pixels is the seed before any selected frontier exists. Tiles arrive already
  in progressive order; every source shuffles a tile once, deterministically,
  as it decodes it, which for the worker-backed source is off the main thread,
  keeping arbitrary COPC record order from biasing early prefixes.
- **Renderer adapter** (`createRendererAdapter`); turns tile batches into
  vtk.js actors, one `vtkPolyData` + `vtkPointGaussianMapper` per tile
  (one gl.POINTS vertex per point, no cell topology), with an anchor base
  matrix composed onto each tile's origin translation. The point adapter is
  exported from `tiled-vtkjs/points/vtk`; the mesh adapter is exported from
  `tiled-vtkjs/tiles3d/vtk`. Both import the pinned `@kitware/vtk.js` fork.
  The `vtkPointGaussianMapper` the point adapter uses is
  not yet in a released vtk.js; see [renderer requirements](#modules-and-renderer-requirements).
  CSS diameter stays separate from framebuffer density: the adapter applies
  device pixel ratio through the mapper at the final rendering boundary.
  `applyDrawPlan` changes each mapper's draw count while its complete
  point/color VBO remains resident. Use `controller.setDensityFraction`
  when an external policy deliberately wants uniform thinning.
  The controller owns residency and the adapter owns actors: `setVisible` is
  a draw switch that keeps every actor alive (batches still apply while
  hidden, so showing again restores exactly the submitted set), while
  releasing a hidden cloud's tiles is the controller's `setActive(false)`.
- **View governor** (`createViewGovernor`); one format-neutral normalized
  fraction per adaptive view. It owns frame-time learning, motion, capacity
  eligibility, and nothing point- or memory-specific. The streamed-scene
  coordinator demand-caps and water-fills that fraction across members while
  the page memory pool allocates bytes separately.

Camera math is pure and renderer-agnostic: the controller takes a
view-projection matrix and camera parameters as plain arrays, and requests
renders only through an injected coalescing `scheduleRender` callback, so the
host owns render pacing. Both projections are first class: a perspective view
shrinks a node's projected spacing with distance, a parallel one is set purely
by `parallelScale`, so an orthographic camera refines on zoom rather than on
approach.

### Point rendering contract

Tile mappers explicitly select `vtkPointGaussianMapper` simple-point mode with
`scaleFactor: 0`. CSS-pixel conversion uses the fork's `pointSizeScale`
extension. Adaptive density uses `maximumPointCount` to submit a prefix without
reuploading resident buffers. Gaussian rendering is not required or enabled.

The adapter writes point size and `maximumPointCount` with vtk.js's
`set(values, true, true)`, which skips `modified()`. vtk.js reads both at draw
time, and a modified property or mapper makes it rebuild and rehash that tile's
shader source, about 0.1 ms a tile, on every point-size or density change.

Custom host integrations must keep `scaleFactor` at zero when applying device
pixel ratio. Use `pointSizeScale` for that conversion; a nonzero `scaleFactor`
requests Gaussian rendering and is rejected by the pinned vtk.js mapper.

## License

[MIT](./LICENSE)

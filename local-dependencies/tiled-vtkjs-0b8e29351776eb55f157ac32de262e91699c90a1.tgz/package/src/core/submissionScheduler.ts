import { finiteAtLeast, wholeAtLeast } from "./numeric";
import { safeCall } from "./observers";

const MiB = 1024 * 1024;

/** Default main-thread/GPU admission limits applied before each paint. */
export const DEFAULT_SUBMISSION_BYTES_PER_FRAME = 16 * MiB;
export const DEFAULT_SUBMISSION_TIME_MS_PER_FRAME = 4;

export type SubmissionJob = {
  /** Estimated retained geometry/texture bytes admitted by this job. */
  readonly bytes: number;
  /** Indivisible resource already checked against its owner's memory budget.
   * If larger than the byte slice, admit it alone; all other work waits. */
  readonly atomic?: boolean;
  /** Synchronous VTK construction or GPU-admission work. */
  readonly run: () => void;
  readonly onError?: (error: unknown) => void;
};

export type Submission = {
  /** Cancel while queued. Returns true only for the first successful cancel. */
  cancel(): boolean;
};

export type SubmissionSchedulerOptions = {
  readonly scheduleRender: () => void;
  readonly maxBytesPerFrame?: number;
  readonly maxTimeMsPerFrame?: number;
  /** Injectable monotonic clock for deterministic tests. */
  readonly now?: () => number;
};

export type SubmissionSchedulerStats = {
  readonly maxBytesPerFrame: number;
  readonly maxTimeMsPerFrame: number;
  readonly queuedJobs: number;
  readonly queuedBytes: number;
  readonly lastFrameAdmittedJobs: number;
  readonly lastFrameAdmittedBytes: number;
  readonly lastFrameElapsedMs: number;
  readonly peakQueuedJobs: number;
  readonly peakFrameAdmittedBytes: number;
};

export type SubmissionScheduler = {
  enqueue(job: SubmissionJob): Submission;
  /** Drain one bounded admission slice immediately before a view paint. */
  prepareFrame(): void;
  hasPending(): boolean;
  stats(): SubmissionSchedulerStats;
  dispose(): void;
};

/** `settled` means admitted or dropped, so it can no longer be cancelled. */
type QueuedJob = SubmissionJob & { cancelled: boolean; settled: boolean };

export const createSubmissionScheduler = (
  options: SubmissionSchedulerOptions,
): SubmissionScheduler => {
  const maxBytes = wholeAtLeast(
    "maxBytesPerFrame",
    options.maxBytesPerFrame ?? DEFAULT_SUBMISSION_BYTES_PER_FRAME,
    1,
  );
  const maxTimeMs = finiteAtLeast(
    "maxTimeMsPerFrame",
    options.maxTimeMsPerFrame ?? DEFAULT_SUBMISSION_TIME_MS_PER_FRAME,
    0,
  );
  const now = options.now ?? (() => performance.now());
  const queue: QueuedJob[] = [];
  let queuedBytes = 0;
  let lastFrameAdmittedJobs = 0;
  let lastFrameAdmittedBytes = 0;
  let lastFrameElapsedMs = 0;
  let peakQueuedJobs = 0;
  let peakFrameAdmittedBytes = 0;
  let disposed = false;

  const discardCancelledHead = (): void => {
    while (queue[0]?.cancelled) queue.shift();
  };

  return {
    enqueue(job) {
      const bytes = wholeAtLeast("submission bytes", job.bytes, 0);
      if (bytes > maxBytes && !job.atomic) {
        throw new Error(
          `submission job is ${bytes} bytes, exceeding the ${maxBytes}-byte per-frame cap; split it into smaller jobs`,
        );
      }
      const queued: QueuedJob = {
        ...job,
        bytes,
        cancelled: false,
        settled: false,
      };
      if (!disposed) {
        const wasEmpty = queue.length === 0;
        queue.push(queued);
        queuedBytes += bytes;
        peakQueuedJobs = Math.max(peakQueuedJobs, queue.length);
        if (wasEmpty) options.scheduleRender();
      } else {
        queued.cancelled = true;
        queued.settled = true;
      }
      return {
        cancel() {
          if (queued.cancelled || queued.settled) return false;
          queued.cancelled = true;
          queuedBytes -= queued.bytes;
          return true;
        },
      };
    },

    prepareFrame() {
      lastFrameAdmittedJobs = 0;
      lastFrameAdmittedBytes = 0;
      lastFrameElapsedMs = 0;
      if (disposed) return;
      const started = now();
      let frameBytes = 0;
      let frameJobs = 0;
      discardCancelledHead();
      while (queue.length > 0) {
        const next = queue[0]!;
        // An indivisible resource may consume a whole frame on its own.
        // Never combine an oversized atomic job with another job.
        if (
          frameJobs > 0 &&
          (frameBytes + next.bytes > maxBytes || now() - started >= maxTimeMs)
        ) {
          break;
        }
        queue.shift();
        next.settled = true;
        queuedBytes -= next.bytes;
        if (next.cancelled) {
          discardCancelledHead();
          continue;
        }
        try {
          next.run();
        } catch (error) {
          safeCall(() => next.onError?.(error));
        }
        frameJobs += 1;
        frameBytes += next.bytes;
        discardCancelledHead();
      }
      lastFrameAdmittedJobs = frameJobs;
      lastFrameAdmittedBytes = frameBytes;
      lastFrameElapsedMs = Math.max(0, now() - started);
      peakFrameAdmittedBytes = Math.max(peakFrameAdmittedBytes, frameBytes);
      if (queue.length > 0) options.scheduleRender();
    },

    hasPending: () => !disposed && queue.some((job) => !job.cancelled),

    stats: () => ({
      maxBytesPerFrame: maxBytes,
      maxTimeMsPerFrame: maxTimeMs,
      queuedJobs: queue.reduce(
        (count, job) => count + (job.cancelled ? 0 : 1),
        0,
      ),
      queuedBytes,
      lastFrameAdmittedJobs,
      lastFrameAdmittedBytes,
      lastFrameElapsedMs,
      peakQueuedJobs,
      peakFrameAdmittedBytes,
    }),

    dispose() {
      if (disposed) return;
      disposed = true;
      for (const job of queue) job.settled = true;
      queue.length = 0;
      queuedBytes = 0;
    },
  };
};

import type { CameraView } from "./camera";
import type { Mat16 } from "./mat4";
import type { MemoryPool } from "./memoryPool";
import type { ScenePoint } from "./frames";
import type { SubmissionScheduler } from "./submissionScheduler";

export type StreamedMemberContext = {
  /** The renderer that owns the streamed anchor. Kept neutral at this seam. */
  readonly renderer: unknown;
  /** Coalescing view render request. Members must never render synchronously. */
  readonly scheduleRender: () => void;
  /** The one page-wide residency pool. The coordinator owns registrations. */
  readonly memory: MemoryPool;
  readonly submissions: SubmissionScheduler;
  readonly devicePixelRatio: number;
  /**
   * Report that this member's inputs may have changed, such as work starting,
   * settling or backing off, without implying new pixels. It only marks the
   * inputs stale: the coordinator reads them once per microtask and never
   * calls the member back from inside this call. This is what keeps retry
   * backoff visible to capacity-sample eligibility.
   */
  readonly onWorkChange?: () => void;
};

declare const IMPORTANCE_BRAND: unique symbol;

/**
 * A member's share-of-view weight, normalized to [0, 1].
 *
 * Branded so it can only be produced by the constructors below: the allocator
 * reads importances only as relative weights, so a screen-space error in
 * pixels must not be passable where a normalized weight is expected.
 */
export type Importance = number & { readonly [IMPORTANCE_BRAND]: true };

/** Nothing of this member is on screen; it contends for no view quality. */
export const CULLED: Importance = 0 as Importance;

/**
 * Weigh a member by how far its root sits above its own refinement cutoff.
 *
 * Both members express demand the same way — "my coarsest visible content is
 * this many times worse than the error I am willing to draw" — so the ratio is
 * comparable across formats even though the underlying content is not.
 */
export const importanceFromRootSseCssPx = (
  rootSseCssPx: number,
  refinementCutoffCssPx: number,
): Importance => {
  if (
    !Number.isFinite(rootSseCssPx) ||
    rootSseCssPx <= 0 ||
    !Number.isFinite(refinementCutoffCssPx) ||
    refinementCutoffCssPx <= 0
  ) {
    return CULLED;
  }
  return Math.min(1, rootSseCssPx / refinementCutoffCssPx) as Importance;
};

export type OutstandingWork = {
  /** Logical queued or in-flight operations still needed for convergence. */
  readonly operations: number;
  /** Monotonic evidence that work completed, failed, was evicted, or admitted. */
  readonly progressSerial: number;
};

export type GovernorInputs = {
  /** Normalized [0, 1] share-of-view weight. Zero means culled. */
  readonly projectedImportance: Importance;
  /** Fraction of full member quality useful to the current view. */
  readonly qualityDemand: number;
  readonly work: OutstandingWork;
  readonly physicalTileOperations: number;
  readonly physicalHierarchyOperations: number;
  readonly residentBytes: number;
  /** Minimum useful coverage and current demand, including refused admissions. */
  readonly memoryDemand?: {
    readonly minimumBytes: number;
    readonly desiredBytes: number;
  };
};

export type AllocationRegime = "moving" | "stationary";

export type Allocation = {
  readonly qualityFraction: number;
  readonly memoryBudgetBytes: number;
  readonly regime: AllocationRegime;
};

export type MemberPickResult =
  | {
      readonly status: "hit";
      /**
       * Positive distance from ray origin along its normalized direction, in
       * the drawn frame. Comparable across members, so a nearer one can veto.
       */
      readonly rayDepth: number;
      /**
       * The hit in canonical scene coordinates — NOT `origin + direction * rayDepth`
       * whenever the member draws in a transformed frame (terrain vertical
       * exaggeration). This is the value the host may store.
       */
      readonly scenePoint: ScenePoint;
      readonly distancePx: number;
    }
  | { readonly status: "miss" };

export type OcclusionResult =
  | { readonly status: "hit"; readonly rayDepth: number }
  | { readonly status: "clear" };

/** The one pick-to-occlusion projection every member shares. */
export const occlusionFromPick = (
  result: MemberPickResult | null,
): OcclusionResult | null =>
  result === null
    ? null
    : result.status === "hit"
      ? { status: "hit", rayDepth: result.rayDepth }
      : { status: "clear" };

/** Renderer-neutral lifecycle every streamed scene format implements. */
export type StreamedMember = {
  setCamera(view: CameraView): void;
  setModelMatrix(matrix: Mat16 | null): void;
  setDevicePixelRatio(devicePixelRatio: number): void;
  setActive(active: boolean): void;
  setConfig(kindConfig: object): void;
  beginInteraction(): void;
  endInteraction(): void;
  prepareFrame(): void;
  /** Coordinator-detected lack of progress; implementations may surface it. */
  onStall?(error: Error): void;
  governorInputs(): GovernorInputs;
  /** Called from the coordinator's `prepareFrame` when it changed, at most once a frame. */
  applyAllocation(allocation: Allocation): void;
  pick(view: CameraView, cssX: number, cssY: number): MemberPickResult | null;
  occlusionDepth(
    view: CameraView,
    cssX: number,
    cssY: number,
  ): OcclusionResult | null;
  stats(): object;
  dispose(): void;
};
